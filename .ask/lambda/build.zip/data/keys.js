const airtable_api_key = "keynLGHM8Jor40KNX";
const airtable_base_data = "appBPrk7Uhqlg1AR3";

module.exports = {
    airtable_api_key,
    airtable_base_data
}